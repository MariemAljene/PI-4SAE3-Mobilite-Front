import { User } from "./user";

export class JwtResponse {
    user: User;
    jwtToken: string;

  }
  