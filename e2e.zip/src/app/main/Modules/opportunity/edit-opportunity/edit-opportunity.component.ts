import { Component, OnInit } from '@angular/core';
import {Opportunity} from "../../../../models/Opportunity";

@Component({
  selector: 'app-edit-opportunity',
  templateUrl: './edit-opportunity.component.html',
  styleUrls: ['./edit-opportunity.component.scss']
})
export class EditOpportunityComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
  }

}
