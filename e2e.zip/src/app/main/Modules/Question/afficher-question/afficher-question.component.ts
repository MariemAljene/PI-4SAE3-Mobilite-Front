import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-afficher-question',
  templateUrl: './afficher-question.component.html',
  styleUrls: ['./afficher-question.component.scss']
})
export class AfficherQuestionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
