import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-condidacy',
  templateUrl: './add-condidacy.component.html',
  styleUrls: ['./add-condidacy.component.scss']
})
export class AddCondidacyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
