export class Event {
    eventId: number;
    name: string ;
    date: Date ;
  }