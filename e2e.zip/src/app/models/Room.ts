export class Room{
    name:   string;
    access:   boolean;
    capacity:  number;
    wasRead:   boolean;
    lastSender:   string;
    roomId: number;
}



  

