export enum Speciality {
  ALL,
  SAE,
  TWIN,
  DS,
  INFINI,
  BI,
  SIM,
  CLOUD,
  NIDS,
  Gamix,
  SLEAM
}
