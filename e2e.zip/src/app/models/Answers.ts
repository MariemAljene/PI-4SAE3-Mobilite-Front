export class Answers {
    id_Answer:number;
    content:String;
    correct:boolean;
}