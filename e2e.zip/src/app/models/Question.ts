import {Answers} from "./Answers";

export class Question {
    content:String;
    Speciality:String;
    image:String;
    point:number;
    idQuestion:number;
    answers:Answers[];

}

