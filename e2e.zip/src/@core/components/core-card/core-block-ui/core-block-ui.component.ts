import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'core-block-ui',
  templateUrl: './core-block-ui.component.html',
  styleUrls: ['./core-block-ui.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CoreBlockUiComponent {
  constructor() {}
}
